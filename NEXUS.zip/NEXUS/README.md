# NEXUS — Autonomous Energy Engineering Command Center

NEXUS is a Streamlit-based decision-support prototype for petroleum production
engineering. This is **NEXUS V1**: a modular foundation covering data quality,
engineering physics, decline curve analysis, anomaly detection, root-cause
hypotheses, forecasting, scenario planning, and economics — built so later
versions can add a full petroleum-engineering calculator, ML layer, and an
AI/RAG assistant on top without reworking the core.

## Project Structure

```
NEXUS/
│
├── app.py            # Main Streamlit application
├── physics.py         # Engineering calculations (rates, DCA models)
├── forecast.py        # Decline curve forecasting
├── anomaly.py          # Statistical + Isolation Forest anomaly detection
├── root_cause.py       # Rule-based root-cause hypothesis engine
├── scenario.py         # Production/water-cut/intervention scenarios
├── economics.py        # Economic impact calculations
├── data_quality.py     # Data quality scoring and cleaning
├── utils.py            # Helpers + synthetic data generator
├── requirements.txt
├── README.md
│
├── data/
│   └── sample_production.csv   # Generated synthetic dataset
│
└── reports/             # (empty — for future exported reports)
```

## Setup

```bash
pip install -r requirements.txt
```

## Run

```bash
streamlit run app.py
```

Your browser should open NEXUS automatically. If it doesn't, visit the local
URL Streamlit prints in the terminal (usually `http://localhost:8501`).

## Modules

- **Command Center** — Field-wide KPIs, production trend, well watchlist.
- **Data Quality** — Missing values, duplicates, outliers, quality score.
- **Well Investigation** — Per-well change metrics + root-cause hypotheses.
- **Anomaly Detection** — Combined statistical (rolling z-score) and
  Isolation Forest anomaly flags.
- **Production Forecast** — 90-day exponential DCA forecast with P10/P50/P90
  bands (simple uncertainty bands, not a rigorous probabilistic model).
- **DCA** — 180-day exponential decline curve fit (qi, Di, R²).
- **Scenario Engine** — Production/intervention scenario + economic impact.
- **Engineering Data** — Full processed dataset + CSV download.

## Data

By default NEXUS generates a synthetic 8-well, 365-day dataset
(`Synthetic Field` mode). Well `NEXUS-03` deliberately contains an injected
anomaly (water breakthrough + pressure drop) between days 220–300 so you can
test the Well Investigation and Anomaly Detection modules end-to-end.

You can also upload your own CSV/XLSX with at least these columns:
`date, well, oil_rate, water_rate, gas_rate, pressure, choke, whp, bhp`.

## Design Principle

NEXUS keeps engineering calculations (DCA, physics ratios, economics)
deterministic and auditable in Python. This separation is intentional: future
AI/LLM layers should **interpret and explain** these outputs rather than
invent calculations themselves.

## Roadmap (not yet implemented)

- **V2** — Full petroleum engineering layer: PVT, OOIP/GIIP, material
  balance, Vogel IPR, well testing, waterflood intelligence.
- **V3** — Expanded ML layer: autoencoder/change-point anomaly detection,
  Random Forest/XGBoost/LSTM/GRU forecasting, SHAP explainability.
- **V4** — RAG layer over engineering documents (PDF/DOCX/XLSX), with the
  LLM required to cite the engineering evidence it used.
- **V5** — Multi-agent orchestration (data, reservoir, production, forecast,
  economics, diagnosis, scenario, red-team agents) producing a full
  engineering report.

Note: don't commit API keys into these files — use Streamlit Secrets
(e.g. `GROQ_API_KEY`, `OPENAI_API_KEY`) once the AI layers are added.
